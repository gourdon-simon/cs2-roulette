export const VERSION = '9.0.6';
//# sourceMappingURL=pkg-version.js.map